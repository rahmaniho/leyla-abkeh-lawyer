import React from 'react'
export default function Navbar(){
  return (
    <header className="fixed top-0 right-0 left-0 bg-black/50 backdrop-blur z-40">
      <div className="container mx-auto flex items-center justify-between p-4">
        <div className="flex items-center gap-3">
          <img src="/public/logo.png" alt="logo" className="h-12 rounded" onError={(e)=>{e.target.src='/public/logo.png'}} />
          <div className="text-gold font-bold">لیلا آبکه</div>
        </div>
        <nav className="hidden md:flex gap-4 text-muted">
          <a href="#home" className="hover:text-white">خانه</a>
          <a href="#about" className="hover:text-white">درباره</a>
          <a href="#services" className="hover:text-white">خدمات</a>
          <a href="#videos" className="hover:text-white">ویدیوها</a>
          <a href="#contact" className="hover:text-white">تماس</a>
        </nav>
        <a href="https://wa.me/989900925811" className="gold-btn px-3 py-2 rounded hidden md:inline">واتساپ</a>
      </div>
    </header>
  )
}
