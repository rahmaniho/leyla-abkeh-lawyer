import React from 'react'
import { motion } from 'framer-motion'

export default function Home(){
  return (
    <section id="home" className="hero-bg min-h-[80vh] relative flex items-center" >
      <div className="absolute inset-0 bg-gradient-to-b from-black/10 to-black/70"></div>
      <div className="container mx-auto relative z-10 py-24 grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
        <motion.div initial={{x:50, opacity:0}} animate={{x:0, opacity:1}} transition={{duration:.7}} className="space-y-4 text-right">
          <h1 className="text-4xl font-extrabold text-[#c9a34a]">لیلا آبکه</h1>
          <p className="text-muted">عضو کانون وکلای دادگستری — دفاع تخصصی در دعاوی کیفری، ملکی و خانواده</p>
          <div className="flex gap-3">
            <a className="gold-btn px-4 py-2 rounded font-bold" href="https://wa.me/989900925811" target="_blank" rel="noreferrer">درخواست مشاوره واتساپ</a>
            <a className="border border-white/10 px-4 py-2 rounded" href="#contact">تماس</a>
          </div>
        </motion.div>
        <motion.div initial={{scale:.9, opacity:0}} animate={{scale:1, opacity:1}} transition={{duration:.8}} className="flex justify-center">
          <img src="/public/portrait.jpg" alt="portrait" className="rounded-xl shadow-lg max-w-[360px]" />
        </motion.div>
      </div>
    </section>
  )
}
