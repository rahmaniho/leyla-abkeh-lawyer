import React from 'react'
export default function Videos(){
  return (
    <section id="videos" className="container mx-auto py-20 text-right">
      <h2 className="text-2xl font-bold text-[#c9a34a]">ویدیوها</h2>
      <div className="mt-6 grid md:grid-cols-2 gap-6">
        <div className="bg-[#0f1720] p-4 rounded-lg"><iframe src="https://www.youtube.com/embed/5kTbQ8ru6S4" title="حقوق خانواده" style={{width:'100%',height:300,borderRadius:8}} frameBorder="0" allowFullScreen></iframe><p className="muted mt-2">آموزش حقوق خانواده — نکات کاربردی</p></div>
        <div className="bg-[#0f1720] p-4 rounded-lg"><iframe src="https://www.youtube.com/embed/6q6t3g1YfZU" title="مهریه" style={{width:'100%',height:300,borderRadius:8}} frameBorder="0" allowFullScreen></iframe><p className="muted mt-2">مبانی مهریه و حقوق طرفین</p></div>
        <div className="bg-[#0f1720] p-4 rounded-lg"><iframe src="https://www.youtube.com/embed/X3bZ0xgqA1M" title="دعاوی ملکی" style={{width:'100%',height:300,borderRadius:8}} frameBorder="0" allowFullScreen></iframe><p className="muted mt-2">دعاوی ملکی — راهنمای پرونده</p></div>
        <div className="bg-[#0f1720] p-4 rounded-lg"><iframe src="https://www.youtube.com/embed/dQw4w9WgXcQ" title="معرفی" style={{width:'100%',height:300,borderRadius:8}} frameBorder="0" allowFullScreen></iframe><p className="muted mt-2">معرفی دفتر و خدمات</p></div>
      </div>
    </section>
  )
}
