import React from 'react'
export default function Services(){
  const items=[
    {t:'وکالت کیفری', d:'دفاع در پرونده‌های کیفری و حضور در دادگاه.'},
    {t:'دعاوی ملکی', d:'اختلافات ملکی، امور ثبتی و تنظیم اسناد.'},
    {t:'خانواده', d:'طلاق، حضانت، نفقه و دعاوی خانوادگی.'},
    {t:'قراردادها', d:'تنظیم، بررسی و اصلاح قراردادها.'},
  ]
  return (
    <section id="services" className="container mx-auto py-20 text-right">
      <h2 className="text-2xl font-bold text-[#c9a34a]">خدمات حقوقی</h2>
      <div className="mt-6 grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        {items.map(i=>(<div key={i.t} className="p-6 bg-[#0f1720] rounded-lg"><h3 className="font-semibold">{i.t}</h3><p className="mt-2 text-muted">{i.d}</p></div>))}
      </div>
    </section>
  )
}
