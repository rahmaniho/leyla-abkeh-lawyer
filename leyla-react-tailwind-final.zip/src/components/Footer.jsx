import React from 'react'
export default function Footer(){
  return (
    <footer className="bg-[#071018] text-muted py-8 mt-12">
      <div className="container mx-auto text-center">
        <p>© ۲۰۲۵ لیلا آبکه — عضو کانون وکلای دادگستری</p>
        <p className="mt-2">قزوین، زیباشهر، روبه‌روی دادگستری — ایمیل: <a href="mailto:leyla.abkeh@gmail.com" className="text-white">leyla.abkeh@gmail.com</a></p>
      </div>
    </footer>
  )
}
