import React, {useRef, useState} from 'react'
import emailjs from 'emailjs-com'

export default function Contact(){
  const form = useRef(null)
  const [status, setStatus] = useState('')
  const send = (e) =>{
    e.preventDefault();
    setStatus('در حال ارسال...');
    emailjs.sendForm('service_73f0khr','template_dmchdso', form.current, 'Sw1TFcvTDolRZBNye')
      .then(()=>{ setStatus('از اعتماد شما سپاسگزاریم — پاسخ شما به‌زودی ارسال خواهد شد.'); form.current.reset(); setTimeout(()=>window.location.href='/thank-you.html',900); })
      .catch((err)=>{ console.error(err); setStatus('خطا در ارسال پیام. لطفاً بعداً تلاش کنید.') })
  }
  return (
    <section id="contact" className="container mx-auto py-20 text-right">
      <h2 className="text-2xl font-bold text-[#c9a34a]">تماس با ما</h2>
      <div className="mt-6 grid md:grid-cols-2 gap-6">
        <form ref={form} onSubmit={send} className="p-6 bg-[#0f1720] rounded-lg">
          <label className="block mb-2">نام و نام خانوادگی</label>
          <input name="from_name" required className="w-full p-2 mb-4 rounded bg-transparent border border-white/5" />
          <label className="block mb-2">ایمیل</label>
          <input type="email" name="from_email" required className="w-full p-2 mb-4 rounded bg-transparent border border-white/5" />
          <label className="block mb-2">پیام</label>
          <textarea name="message" rows="5" required className="w-full p-2 mb-4 rounded bg-transparent border border-white/5" />
          <button type="submit" className="gold-btn px-4 py-2 rounded font-bold">ارسال پیام</button>
          <p className="muted mt-3">{status}</p>
        </form>
        <div className="p-6 bg-[#0f1720] rounded-lg">
          <p>آدرس: قزوین، زیباشهر، روبه‌روی دادگستری</p>
          <p className="mt-2">واتساپ: <a href="https://wa.me/989900925811">۰۹۹۰ ۰۹۲ ۵۸۱۱</a></p>
          <p className="mt-2">ایمیل: <a href="mailto:leyla.abkeh@gmail.com">leyla.abkeh@gmail.com</a></p>
        </div>
      </div>
    </section>
  )
}
