import React from 'react'
export default function About(){
  return (
    <section id="about" className="container mx-auto py-20 text-right">
      <h2 className="text-2xl font-bold text-[#c9a34a]">درباره من</h2>
      <div className="mt-6 grid md:grid-cols-3 gap-6">
        <div className="p-6 bg-[#0f1720] rounded-lg">من لیلا آبکه، عضو کانون وکلای دادگستری قزوین هستم. سال‌ها تجربه در دعاوی کیفری، ملکی و خانواده دارم و به پرونده موکلان با تعهد و دقت می‌پردازم.</div>
        <div className="p-6 bg-[#0f1720] rounded-lg">تحصیلات: کارشناسی حقوق.</div>
        <div className="p-6 bg-[#0f1720] rounded-lg">برای مشاوره تماس بگیرید: <a href="https://wa.me/989900925811">۰۹۹۰ ۰۹۲ ۵۸۱۱</a></div>
      </div>
    </section>
  )
}
